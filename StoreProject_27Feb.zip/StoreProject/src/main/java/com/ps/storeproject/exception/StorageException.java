package com.ps.storeproject.exception;

public class StorageException extends RuntimeException {

	public StorageException(String msg) {
		super(msg);
	}
}
